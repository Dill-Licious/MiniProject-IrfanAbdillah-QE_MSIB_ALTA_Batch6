import { Given, When, Then, Before, After } from "@cucumber/cucumber";
import assert from "assert";

import initDriver from "../../configs/driver.js";
import AddNewItemPage from "../../pages/addNewItemPage.js";
import MyGroceriesPage from "../../pages/MyGroceriesPage.js";

let driver;
let addNewItemPage;
let myGroceriesPage;

Before({ timeout: 6000 * 10000 }, async () => {
  try {
    driver = await initDriver();
    addNewItemPage = new AddNewItemPage(driver);
    myGroceriesPage = new MyGroceriesPage(driver);
  } catch (error) {
    console.error(error);
  }
});

//Positif Scenario Add New Item
Given("I am on my groceries page", async () => {
  const groceriesTitle = await myGroceriesPage.getMyGroceriesPageTitle();
  assert.equal(groceriesTitle, "Your Groceries");
});

When("I click the add button to add a new item to my groceries list", async () => {
  await myGroceriesPage.tapAddItemButton();
});

Then("I am redirected to the page to add a new item", async () => {
  const newItemtTitle = await addNewItemPage.getAddNewItemPageTitle();
  assert.equal(newItemtTitle, "Add a new item");
});

Then("I input the item name with valid credentials", async () => {
  const inputItem = "Melon";
  await addNewItemPage.insertItemName(inputItem);
});

Then("I input the quantity of the item with valid credentials", async () => {
  const inputQuantity = "10";
  await addNewItemPage.clearQuantity();
  await addNewItemPage.insertQuantity(inputQuantity);
});

Then("I select the type of groceries", async () => {
  await addNewItemPage.chooseCategoriesOption();
});

Then("I click the add item button" , async () => {
  await addNewItemPage.tapAddNewItemButton();
});

//Negatif Scenario Add New Item
Then("I should see an error message in the name field indicating a minimum character requirement of 1 to 50", async () => {
  const errorMessageMinumumCharacter = await addNewItemPage.errorMessageInNameField();
  assert.equal(errorMessageMinumumCharacter, "Must be between 1 and 50 characters.");
});

Then("I clear the quantity field", async () => {
  await addNewItemPage.clearQuantity();
});

Then("I should see an error message in the quantity field indicating that the quantity must be a positive number", async () => {
  const errorMessageMustBePositiveNumber = await addNewItemPage.errorMessageInQuantityField();
  assert.equal(errorMessageMustBePositiveNumber, "Must be a valid positive number.");
});

Then("I input the quantity of the item with special character", async () => {
  const inputQuantityWithSpecialCharacter = "-";
  await addNewItemPage.clearQuantity();
  await addNewItemPage.insertQuantity(inputQuantityWithSpecialCharacter);
});

Then("I input the item name with special character", async () => {
  const inputItem = ":) :> :~";
  await addNewItemPage.insertItemName(inputItem);
});


// Reset to Default Feature
Then("I click the reset button to clear all entered data", async () => {
  await addNewItemPage.tapResetButton();
});

Then("I should see the name field reset to its default value", async () => {
  const defaultNameField = await addNewItemPage.defaultNameField();
  assert.equal(defaultNameField, "Name");
});

Then("I should see the quantity field reset to its default value", async () =>{
  const defaultQuantityField = await addNewItemPage.defaultQuantityField();
  assert.equal(defaultQuantityField, "1, Quantity");
})

// Return to my groceries
Then("I click the back button to return to the My Groceries page", async () =>{
  await addNewItemPage.tapBackButton();
});

After(async () => {
  await driver.deleteSession();
});