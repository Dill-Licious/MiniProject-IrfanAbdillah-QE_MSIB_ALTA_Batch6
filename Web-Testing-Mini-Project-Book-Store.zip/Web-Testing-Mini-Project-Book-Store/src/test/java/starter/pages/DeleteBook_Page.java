package starter.pages;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class DeleteBook_Page extends PageObject {
    //Object
    private By deleteBookPageTitle(){
        return By.xpath("//*[@id=\"root\"]/div/h1");
    }

    private By deleteBookButton(){
        return By.xpath("//*[@id=\"root\"]/div/div[2]/button");
    }

    @Step
    public boolean validateDeleteBookPageTitleDisplayed(){
        return $(deleteBookPageTitle()).isDisplayed();
    }

    @Step
    public void clickYesDeletedBookButton(){
        $(deleteBookButton()).click();
    }


}
