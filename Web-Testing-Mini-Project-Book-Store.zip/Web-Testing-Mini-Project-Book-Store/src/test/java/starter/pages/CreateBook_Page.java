package starter.pages;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class CreateBook_Page extends PageObject {
    private By bookTitle(){
        return By.xpath("//*[@id=\"root\"]/div/h1");
    }

    private By titleField(){
        return By.id("title");
    }

    private By authorField(){
        return By.id("author");
    }

    private By publishYearField(){
        return By.id("publishYear");
    }

    private By saveBookButton(){
        return By.xpath("//*[@id=\"root\"]/div[1]/div[2]/button");
    }

    private By errorMessageFailedCreateBook(){
        return By.xpath("//*[@id=\"root\"]/div[2]/div/div/div/div");
    }

    @Step
    public boolean validateOnTheCreateBookPage(){
        return $(bookTitle()).isDisplayed();
    }

    @Step
    public void inputTitle(String title){
        $(titleField()).type(title);
    }

    @Step
    public void inputAuthor(String author){
        $(authorField()).type(author);
    }

    @Step
    public void inputPublishYear(String year){
        $(publishYearField()).type(year);
    }

    @Step
    public void clickSaveBookButton(){
        $(saveBookButton()).click();
    }

    @Step
    public boolean validateErrorMessageFailedCreateBookDisplayed(){
        return $(errorMessageFailedCreateBook()).isDisplayed();
    }

    @Step
    public boolean confirmErrorMessageFailedCreateBook(String message){
        return $(errorMessageFailedCreateBook()).getText().equalsIgnoreCase(message);
    }
}
