package starter.pages;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class BookList_Page extends PageObject {
    //Object
    private By bookListTitle(){
        return By.xpath("//*[@id=\"root\"]/div/div[2]/h1");
    }

    private By confirmMessageSuccessAddedBook(){
        return By.id("notistack-snackbar");
    }

    private By createButton(){
        return By.xpath("//*[@id=\"root\"]/div/div[2]/a");
    }

    private By bookListsTable(){
        return By.xpath("//*[@id=\"root\"]/div/table");
    }

    private By operations(){
        return By.xpath("//*[@id=\"root\"]/div/table/tbody/tr[1]/td[5]/div");
    }

    private By detailBookButton(){
        return By.xpath("//*[@id=\"root\"]/div/table/tbody/tr[1]/td[5]/div/a[1]");
    }

    private By detailBookButtonCardFormat(){
        return By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/div[3]/a[1]");
    }

    private By cardModeButton(){
        return By.xpath("//*[@id=\"root\"]/div/div[1]/button[2]");
    }

    private By bookListInCardFormat(){
        return By.xpath("//*[@id=\"root\"]/div/div[3]");
    }

    private By firstBookData(){
        return By.xpath("//*[@id=\"root\"]/div/table/tbody/tr[1]");
    }

    private By deleteBookButton(){
        return By.xpath("//*[@id=\"root\"]/div[1]/table/tbody/tr[1]/td[5]/div/a[3]");
    }

    private By deleteBookButtonCardFormat(){
        return By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/div[3]/a[3]");
    }

    private By confirmationMessageSuccessDeletedBook(){
        return By.xpath("//*[@id=\"root\"]/div[2]");
    }

    private By editButton(){
        return By.xpath("//*[@id=\"root\"]/div/table/tbody/tr[1]/td[5]/div/a[2]");
    }

    private By editButtonCardFormat(){
        return By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/div[3]/a[2]");
    }

    private By tableModeButton(){
        return By.xpath("//*[@id=\"root\"]/div/div[1]/button[1]");
    }

    private By toggleButton(){
        return By.cssSelector("#root > div > div.grid.sm\\:grid-cols-2.lg\\:grid-cols-3.xl\\:grid-cols-4 > div:nth-child(2) > div.flex.justify-between.items-center.gap-x-2.mt-4.p-4 > svg");
    }

    private By popUpRecapInformationCardMode(){
        return By.cssSelector("#root > div > div.grid.sm\\:grid-cols-2.lg\\:grid-cols-3.xl\\:grid-cols-4 > div:nth-child(2) > div.fixed.bg-black.bg-opacity-60.top-0.left-0.right-0.bottom-0.z-50.flex.justify-center.items-center > div > svg");
    }

    //Step
    @Step
    public boolean validateOnBookListPage(){
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return $(bookListTitle()).isDisplayed();
    }

    @Step
    public void clickCreateButton(){
        $(createButton()).click();
    }

    @Step
    public boolean validateMessageSuccessAddedBook(String message){
        return $(confirmMessageSuccessAddedBook()).getText().equalsIgnoreCase(message);
    }

    @Step
    public boolean validateSuccessMessageDisplayed(){
        return $(confirmMessageSuccessAddedBook()).isDisplayed();
    }


    @Step
    public boolean validateSeeBookListTable(){
        return $(bookListsTable()).isDisplayed();
    }

    @Step
    public boolean validateSeeOperations(){
        return $(operations()).isDisplayed();
    }

    @Step
    public void clickDetailBookButton(){
        $(detailBookButton()).click();
    }

    @Step
    public boolean validateCardModeButton(){
        return $(cardModeButton()).isDisplayed();
    }

    @Step
    public void clickCardModeButton(){
        $(cardModeButton()).click();
    }

    @Step
    public boolean validateBookListInCartFormat(){
        return $(bookListInCardFormat()).isDisplayed();
    }

    @Step
    public boolean validateFirstBookData(){
        return $(firstBookData()).isDisplayed();
    }

    @Step
    public void clickDeleteBookButton(){
        $(deleteBookButton()).click();
    }

    @Step
    public boolean validateConfirmationMessageSuccessDeletedBook(String message){
        return $(confirmationMessageSuccessDeletedBook()).getText().equalsIgnoreCase(message);
    }

    @Step
    public boolean validateSuccessMessageDeletedBookDisplayed(){
        return $(confirmationMessageSuccessDeletedBook()).isDisplayed();
    }

    @Step
    public void clickEditButton(){
        $(editButton()).click();
    }


    @Step
    public boolean validateTableModeButton(){
        return $(tableModeButton()).isDisplayed();
    }

    @Step
    public void clickTableModeButton(){
        $(tableModeButton()).click();
    }

    @Step
    public boolean validateToggleButton(){
        return $(toggleButton()).isDisplayed();
    }

    @Step
    public void clickToggleButton(){
        $(toggleButton()).click();
    }

    @Step
    public boolean validatePopUpRecapInformationCardMode(){
        return $(popUpRecapInformationCardMode()).isDisplayed();
    }

    @Step
    public void clickDetailBookButtonCardFormat(){
        $(detailBookButtonCardFormat()).click();
    }

    @Step
    public void clickEditButtonCardFormat(){
        $(editButtonCardFormat()).click();
    }

    @Step
    public void clickDeleteBookButtonCardFormat(){
        $(deleteBookButtonCardFormat()).click();
    }
}
