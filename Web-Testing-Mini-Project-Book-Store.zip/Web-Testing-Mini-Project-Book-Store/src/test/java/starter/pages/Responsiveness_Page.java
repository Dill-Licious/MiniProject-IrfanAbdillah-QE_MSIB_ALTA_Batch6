package starter.pages;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.Dimension;

public class Responsiveness_Page extends PageObject {

    @Step
    public void testMobileResponsiveness(){
        getDriver().manage().window().setSize(new Dimension(360, 640));
    }

    @Step
    public void testTabletResponsiveness(){
        getDriver().manage().window().setSize(new Dimension(768, 1024));
    }
}
