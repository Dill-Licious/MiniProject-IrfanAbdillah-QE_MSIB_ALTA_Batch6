package starter.pages;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class EditBook_Page extends PageObject {
    private By editBookPageTitle(){
        return By.xpath("//*[@id=\"root\"]/div/h1");
    }

    private By titleField(){
        return By.id("title");
    }

    private By authorField(){
        return By.id("author");
    }

    private By publishYearField(){
        return By.id("publishYear");
    }

    private By editBookButton(){
        return By.xpath("//*[@id=\"root\"]/div/div[2]/button");
    }


    @Step
    public boolean validateOnTheEditBookPage(){
        return $(editBookPageTitle()).isDisplayed();
    }


    @Step
    public void removedTitleData(){
        $(titleField()).clear();
    }

    @Step
    public void removedAuthorData(){
        $(authorField()).clear();
    }

    @Step
    public void removedPublishDataYear(){
        $(publishYearField()).clear();
    }

    @Step
    public void clickEditBookButton(){
        $(editBookButton()).click();
    }
}
