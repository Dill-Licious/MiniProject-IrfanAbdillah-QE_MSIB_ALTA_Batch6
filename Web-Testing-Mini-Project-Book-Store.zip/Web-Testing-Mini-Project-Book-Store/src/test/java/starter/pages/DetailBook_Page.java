package starter.pages;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class DetailBook_Page extends PageObject {
    // Object
    private By detailBookTitle(){
        return By.xpath("//*[@id=\"root\"]/div/div[2]");
    }

    private By columnDetailBookInfo(){
        return By.xpath("//*[@id=\"root\"]/div/div[2]");
    }

    private By confirmationMessageSuccessEditBookData(){
        return By.xpath("//*[@id=\"root\"]/div[2]/div/div/div/div");
    }

    //Step
    @Step
    public boolean validateOnTheDetailBookPage(){
        return $(detailBookTitle()).isDisplayed();
    }

    @Step
    public boolean validateSeeDetailBookInfo(){
        return $(columnDetailBookInfo()).isDisplayed();
    }

    @Step
    public boolean validateSuccessEditBookMessageDisplayed(){
        return $(confirmationMessageSuccessEditBookData()).isDisplayed();
    }

    @Step
    public boolean validateConfirmSuccessEditBookMessage(String message){
        return $(confirmationMessageSuccessEditBookData()).getText().equalsIgnoreCase(message);
    }
}
