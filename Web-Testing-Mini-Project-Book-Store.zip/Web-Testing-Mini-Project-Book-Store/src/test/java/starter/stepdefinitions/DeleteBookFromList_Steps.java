package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.BookList_Page;
import starter.pages.DeleteBook_Page;

public class DeleteBookFromList_Steps {
    @Steps
    BookList_Page bookListPage;

    @Steps
    DeleteBook_Page deleteBookPage;

    @And("I see the data of the first book")
    public void validateFirstBookData(){
        Assertions.assertTrue(bookListPage.validateFirstBookData());
    }

    @And("I click on the delete button for the first book data")
    public void clickDeleteBookButton(){
        bookListPage.clickDeleteBookButton();
    }

    @Then("I am redirected to the confirmation delete book page")
    public void validateDeleteBookPageTitleDisplayed(){
        Assertions.assertTrue(deleteBookPage.validateDeleteBookPageTitleDisplayed());
    }

    @And("I click on the \"Yes\" button")
    public void clickYesDeletedBookButton(){
        deleteBookPage.clickYesDeletedBookButton();
    }

    @Then("I will be redirected to the book list page with a confirmation message stating {string}")
    public void validateConfirmationMessageSuccessDeletedBook(String message){
        Assertions.assertTrue(bookListPage.validateSuccessMessageDeletedBookDisplayed());
        Assertions.assertTrue(bookListPage.validateConfirmationMessageSuccessDeletedBook(message));
    }
}
