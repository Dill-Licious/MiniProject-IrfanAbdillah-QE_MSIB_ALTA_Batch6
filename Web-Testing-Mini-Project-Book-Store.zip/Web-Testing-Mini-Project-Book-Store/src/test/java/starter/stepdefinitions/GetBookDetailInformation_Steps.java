package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.BookList_Page;
import starter.pages.DetailBook_Page;

public class GetBookDetailInformation_Steps {
    @Steps
    BookList_Page bookListPage;

    @Steps
    DetailBook_Page detailBookPage;

    @When("I see a table of the book list containing all books")
    public void validateSeeBookListTable(){
        Assertions.assertTrue(bookListPage.validateSeeBookListTable());
    }

    @And("I see an operation that can be used for every book")
    public void validateSeeOperations(){
        Assertions.assertTrue(bookListPage.validateSeeOperations());
    }

    @And("I click on the detail button for the first book data")
    public void clickDetailBookButton(){
        bookListPage.clickDetailBookButton();
    }

    @Then("I redirect to detail book information page")
    public void validateOnTheDetailBookPage(){
        Assertions.assertTrue(detailBookPage.validateOnTheDetailBookPage());
    }

    @And("I can see detailed book information presented in column format")
    public void validateSeeDetailBookInfo(){
        Assertions.assertTrue(detailBookPage.validateSeeDetailBookInfo());

    }
}
