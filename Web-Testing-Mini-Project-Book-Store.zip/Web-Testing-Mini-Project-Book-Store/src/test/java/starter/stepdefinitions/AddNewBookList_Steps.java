package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.BookList_Page;
import starter.pages.CreateBook_Page;

public class AddNewBookList_Steps {
    @Steps
    BookList_Page bookListPage;

    @Steps
    CreateBook_Page createBookPage;

    @Given("I am on the book list page")
    public void validateOnTheBookListPage(){
        bookListPage.openUrl("https://mini-book-store-fe.vercel.app/");
        Assertions.assertTrue(bookListPage.validateOnBookListPage());
    }

    @When("I click create button")
    public void clickCreateButton(){
        bookListPage.clickCreateButton();
    }

    @And("I am on the create book page")
    public void validateOnTheCreateBookPage(){
        Assertions.assertTrue(createBookPage.validateOnTheCreateBookPage());
    }

    @And("I input title with valid credentials")
    public void inputTitle(){
        createBookPage.inputTitle("Avatar Volume 3");
    }

    @And("I input author with valid credentials")
    public void inputAuthor(){
        createBookPage.inputAuthor("JMichael Dante DiMartino");
    }

    @And("I input publish year with valid credentials")
    public void inputPublishYear(){
        createBookPage.inputPublishYear("2018");
    }

    @And("I click save book button")
    public void clickSaveBookButton(){
        createBookPage.clickSaveBookButton();
    }

    @Then("I will be redirected to the book list page with a confirmation message saying {string}")
    public void validateMessageSuccessAddedBook(String message){
        Assertions.assertTrue(bookListPage.validateSuccessMessageDisplayed());
        Assertions.assertTrue(bookListPage.validateMessageSuccessAddedBook(message));
    }


    //Negatif Scenario
    @And("I input publish year with negative value")
    public void inputInvalidPublishYear(){
        createBookPage.inputPublishYear("-100");
    }

    @Then("I will see error message saying {string}")
    public void validateErrorMessageFailedCreateBook(String message){
        Assertions.assertTrue(createBookPage.validateErrorMessageFailedCreateBookDisplayed());
        Assertions.assertTrue(createBookPage.confirmErrorMessageFailedCreateBook(message));
    }


    @And("I input title with null value")
    public void inputNullValueTitle(){
        createBookPage.inputTitle("");
    }


    @And("I input author with null value")
    public void inputNullValueAuthor(){
        createBookPage.inputAuthor("");
    }

    @And("I input publish year with null value")
    public void inputNullValuePublishYear(){
        createBookPage.inputPublishYear("");
    }
}
