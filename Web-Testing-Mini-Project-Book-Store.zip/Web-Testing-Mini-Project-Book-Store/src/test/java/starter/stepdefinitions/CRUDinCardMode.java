package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.BookList_Page;

public class CRUDinCardMode {
    @Steps
    BookList_Page bookListPage;

    @And("I can see the toggle button to view a simplified recap about the book")
    public void validateToggleButton(){
        Assertions.assertTrue(bookListPage.validateToggleButton());
    }

    @And("I click toggle button")
    public void clickToggleButton(){
        bookListPage.clickToggleButton();
    }

    @Then("I can view information about the book's name, author, publication year, and ID in the form of a pop-up")
    public void validatePopUpRecapInformationCardMode(){
        Assertions.assertTrue(bookListPage.validatePopUpRecapInformationCardMode());
    }

    @And("I click on the detail button for the first book data in card format")
    public void clickDetailBookButtonCardFormat(){
        bookListPage.clickDetailBookButtonCardFormat();
    }

    @And("I click on the edit button for the first book data in card format")
    public void clickEditButtonCardFormat(){
        bookListPage.clickEditButtonCardFormat();
    }

    @And("I click on the delete button for the first book data in card format")
    public void clickDeleteBookButtonCardFormat(){
        bookListPage.clickDeleteBookButtonCardFormat();
    }
}
