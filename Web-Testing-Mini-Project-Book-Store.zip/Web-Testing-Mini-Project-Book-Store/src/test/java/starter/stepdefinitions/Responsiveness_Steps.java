package starter.stepdefinitions;

import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Steps;
import starter.pages.Responsiveness_Page;

public class Responsiveness_Steps {
    @Steps
    Responsiveness_Page responsivenessPage;

    @When("I set the responsiveness to mobile size")
    public void testMobileResponsiveness(){
        responsivenessPage.testMobileResponsiveness();
    }

    @When("I set the responsiveness to tablet size")
    public void testTabletResponsiveness(){
        responsivenessPage.testTabletResponsiveness();
    }
}
