package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.BookList_Page;
import starter.pages.DetailBook_Page;
import starter.pages.EditBook_Page;

public class EditBookData_Steps {
    @Steps
    BookList_Page bookListPage;

    @Steps
    DetailBook_Page detailBookPage;

    @Steps
    EditBook_Page editBookPage;

    @And("I click on the edit button for the first book data")
    public void clickEditButton(){
        bookListPage.clickEditButton();
    }

    @Then("I redirect to edit detail book information page")
    public void validateOnTheEditBookPage(){
        Assertions.assertTrue(editBookPage.validateOnTheEditBookPage());
    }

    @And("I removed the old data regarding the title")
    public void removedTitleData(){
        editBookPage.removedTitleData();
    }

    @And("I removed the old data regarding the author")
    public void removedAuthorData(){
        editBookPage.removedAuthorData();
    }

    @And("I removed the old data regarding the publish year")
    public void removedPublishDataYear(){
        editBookPage.removedPublishDataYear();
    }

    @And("I click edit book button")
    public void clickEditBookButton(){
        editBookPage.clickEditBookButton();
    }

    @Then("I will be redirected to the book detail page with a confirmation message saying {string}")
    public void validateConfirmMessageSuccessEdit(String message){
        Assertions.assertTrue(detailBookPage.validateSuccessEditBookMessageDisplayed());
        Assertions.assertTrue(detailBookPage.validateConfirmSuccessEditBookMessage(message));

    }

}
