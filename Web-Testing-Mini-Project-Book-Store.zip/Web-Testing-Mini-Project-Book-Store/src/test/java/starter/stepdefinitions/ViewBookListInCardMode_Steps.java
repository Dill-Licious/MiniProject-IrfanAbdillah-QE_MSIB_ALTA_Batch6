package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.BookList_Page;

public class ViewBookListInCardMode_Steps {
    @Steps
    BookList_Page bookListPage;

    @When("I see card mode button")
    public void validateCardModeButton(){
        Assertions.assertTrue(bookListPage.validateCardModeButton());
    }

    @And("I click card mode button")
    public void clickCardModeButton(){
        bookListPage.clickCardModeButton();
    }

    @Then("I can see detailed book information presented in card format")
    public void validateBookListInCartFormat(){
        Assertions.assertTrue(bookListPage.validateBookListInCartFormat());
    }

    @And("I see table mode button")
    public void validateTableModeButton(){
        Assertions.assertTrue(bookListPage.validateTableModeButton());
    }

    @And("I click table mode button")
    public void clickTableModeButton(){
        bookListPage.clickTableModeButton();
    }

}

